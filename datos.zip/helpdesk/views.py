from django.conf import settings
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import filters, permissions, status, throttling, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response

from .models import Ticket, Usuario
from .serializers import TicketSerializer, UsuarioSerializer


class Login(ObtainAuthToken):
    throttle_classes = [throttling.ScopedRateThrottle]
    throttle_scope = 'login'

    # MODIFICADO: devuelve el rol real junto con el token.
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(
            data=request.data,
            context={'request': request},
        )
        serializer.is_valid(raise_exception=True)

        cuenta = serializer.validated_data['user']
        grupos = set(cuenta.groups.values_list('name', flat=True))

        if cuenta.is_superuser or Usuario.Rol.ADMINISTRADOR in grupos:
            rol = Usuario.Rol.ADMINISTRADOR
        elif Usuario.Rol.SOPORTE in grupos:
            rol = Usuario.Rol.SOPORTE
        elif Usuario.Rol.USUARIO in grupos:
            rol = Usuario.Rol.USUARIO
        else:
            return Response(
                {'detail': 'La cuenta no tiene un rol asignado en el Help Desk.'},
                status=status.HTTP_403_FORBIDDEN,
            )

        token, _ = Token.objects.get_or_create(user=cuenta)

        return Response({
            'token': token.key,
            'rol': rol,
            'username': cuenta.get_username(),
        })


class PermisoHelpDesk(permissions.BasePermission):
    def has_permission(self, request, view):
        if settings.MODO_LOCAL_ABIERTO:
            return True

        usuario = request.user
        if not usuario.is_authenticated:
            return False

        if request.method in permissions.SAFE_METHODS or usuario.is_superuser:
            return True

        grupos = [Usuario.Rol.ADMINISTRADOR]

        if view.basename == 'tickets' and request.method != 'DELETE':
            grupos.append(Usuario.Rol.SOPORTE)

        return usuario.groups.filter(name__in=grupos).exists()


class RecursoHelpDesk(viewsets.ModelViewSet):
    permission_classes = [PermisoHelpDesk]

    def get_authenticators(self):
        if settings.MODO_LOCAL_ABIERTO:
            return []

        return super().get_authenticators()


class TicketViewSet(RecursoHelpDesk):
    queryset = Ticket.objects.order_by('fechaCreacion', 'id')
    serializer_class = TicketSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['asunto', 'descripcion']
    ordering_fields = ['fechaCreacion', 'prioridad', 'estado', 'asunto']

    def get_queryset(self):
        tickets = super().get_queryset()

        for campo in ('estado', 'prioridad', 'fechaCreacion'):
            valor = self.request.query_params.get(campo)

            if not valor:
                continue

            if campo == 'fechaCreacion':
                try:
                    tickets = tickets.filter(fechaCreacion=valor)
                except DjangoValidationError as error:
                    raise ValidationError(
                        {'fechaCreacion': 'Usa AAAA-MM-DD.'}
                    ) from error
            else:
                tickets = tickets.filter(**{campo: valor})

        return tickets


class UsuarioViewSet(RecursoHelpDesk):
    queryset = Usuario.objects.order_by('nombre', 'id')
    serializer_class = UsuarioSerializer